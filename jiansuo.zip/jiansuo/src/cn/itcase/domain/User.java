package cn.itcase.domain;

public class User {
    private Integer id;
    private String name;
    private String type;
    private String category;
    private String range;
    private String document;
    private String form;
    private String organ;
    private String viadata;
    private String pubdata;
    private String perdata;
    private String field;
    private String theme;
    private String keyword;
    private String superior;
    private String precursor;
    private String succeed;
    private String state;
    private String text;
    private String pdf;
    private String redundancy;
    private String rank;
    private String policykey;
    private String newrank;
    private String year;
    private String newkey;
    private String secondtheme;
    private String allsum;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getRange() {
        return range;
    }

    public void setRange(String range) {
        this.range = range;
    }

    public String getDocument() {
        return document;
    }

    public void setDocument(String document) {
        this.document = document;
    }

    public String getForm() {
        return form;
    }

    public void setForm(String form) {
        this.form = form;
    }

    public String getOrgan() {
        return organ;
    }

    public void setOrgan(String organ) {
        this.organ = organ;
    }

    public String getViadata() {
        return viadata;
    }

    public void setViadata(String viadata) {
        this.viadata = viadata;
    }

    public String getPubdata() {
        return pubdata;
    }

    public void setPubdata(String pubdata) {
        this.pubdata = pubdata;
    }

    public String getPerdata() {
        return perdata;
    }

    public void setPerdata(String perdata) {
        this.perdata = perdata;
    }

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public String getTheme() {
        return theme;
    }

    public void setTheme(String theme) {
        this.theme = theme;
    }

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    public String getSuperior() {
        return superior;
    }

    public void setSuperior(String superior) {
        this.superior = superior;
    }

    public String getPrecursor() {
        return precursor;
    }

    public void setPrecursor(String precursor) {
        this.precursor = precursor;
    }

    public String getSucceed() {
        return succeed;
    }

    public void setSucceed(String succeed) {
        this.succeed = succeed;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }
    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getPdf() {
        return pdf;
    }

    public void setPdf(String pdf) {
        this.pdf = pdf;
    }

    public String getRedundancy() {
        return redundancy;
    }

    public void setRedundancy(String redundancy) {
        this.redundancy = redundancy;
    }

    public String getRank() {
        return rank;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }

    public String getPolicykey() {
        return policykey;
    }

    public void setPolicykey(String policykey) {
        this.policykey = policykey;
    }

    public String getNewrank() {
        return newrank;
    }

    public void setNewrank(String newrank) {
        this.newrank = newrank;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getNewkey() {
        return newkey;
    }

    public void setNewkey(String newkey) {
        this.newkey = newkey;
    }

    public String getSecondtheme() {
        return secondtheme;
    }

    public void setSecondtheme(String secondtheme) {
        this.secondtheme = secondtheme;
    }

    public String getAllsum() {
        return allsum;
    }

    public void setAllsum(String allsum) {
        this.allsum = allsum;
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", type='" + type + '\'' +
                ", category='" + category + '\'' +
                ", range='" + range + '\'' +
                ", document='" + document + '\'' +
                ", form='" + form + '\'' +
                ", organ='" + organ + '\'' +
                ", viadata='" + viadata + '\'' +
                ", pubdata='" + pubdata + '\'' +
                ", perdata='" + perdata + '\'' +
                ", field='" + field + '\'' +
                ", theme='" + theme + '\'' +
                ", keyword='" + keyword + '\'' +
                ", superior='" + superior + '\'' +
                ", precursor='" + precursor + '\'' +
                ", succeed='" + succeed + '\'' +
                ", state='" + state + '\'' +
                ", pdf='" + text + '\'' +
                ", pdf='" + pdf + '\'' +
                ", redundancy='" + redundancy + '\'' +
                ", rank='" + rank + '\'' +
                ", policykey='" + policykey + '\'' +
                ", newrank='" + newrank + '\'' +
                ", year='" + year + '\'' +
                ", newkey='" + newkey + '\'' +
                ", secondtheme='" + secondtheme + '\'' +
                ", allsum='" + allsum + '\'' +
                '}';
    }

    public User(Integer id, String name, String type, String category, String range, String document, String form, String organ, String viadata, String pubdata, String perdata, String field, String theme, String keyword, String superior, String precursor, String succeed, String state,String text, String pdf, String redundancy, String rank, String policykey, String newrank, String year, String newkey, String secondtheme, String allsum) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.category = category;
        this.range = range;
        this.document = document;
        this.form = form;
        this.organ = organ;
        this.viadata = viadata;
        this.pubdata = pubdata;
        this.perdata = perdata;
        this.field = field;
        this.theme = theme;
        this.keyword = keyword;
        this.superior = superior;
        this.precursor = precursor;
        this.succeed = succeed;
        this.state = state;
        this.text = text;
        this.pdf = pdf;
        this.redundancy = redundancy;
        this.rank = rank;
        this.policykey = policykey;
        this.newrank = newrank;
        this.year = year;
        this.newkey = newkey;
        this.secondtheme = secondtheme;
        this.allsum = allsum;
    }

    public User() {
    }

}